import AuthForm from "@/components/AuthForm";

const Page = () => {
  return <AuthForm type="sign-in" />;//added shadcn layout for sign and sign up 
};

export default Page;
